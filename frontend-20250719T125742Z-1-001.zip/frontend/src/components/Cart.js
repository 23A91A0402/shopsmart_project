import React from 'react';

export default function Cart({ cart }) {
  return (
    <div>
      <h2>Cart</h2>
      {cart.map((item, index) => (
        <div key={index}>{item.name} - ₹{item.price}</div>
      ))}
    </div>
  );
}